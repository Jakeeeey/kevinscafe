<?= $this->extend('templates/base'); ?>

<?= $this->section('title'); ?>
    <?= $page_title; ?>
<?= $this->endSection(); ?>

<?= $this->section('body'); ?>

    <div class="container" style="margin-top:80px">
        <h1 style="text-align: center;">Under Construction</h1>
        <h1>Location</h1>

        
    </div>
    
<?= $this->endSection(); ?>