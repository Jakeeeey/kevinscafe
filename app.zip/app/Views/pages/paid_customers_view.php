<?= $this->extend('templates/base'); ?>

<?= $this->section('title'); ?>
    <?= $page_title; ?>
<?= $this->endSection(); ?>

<?= $this->section('body'); ?>
    <h1>Paid Customers</h1>
    
<?= $this->endSection(); ?>