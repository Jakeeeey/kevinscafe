<?= $this->extend('templates/base'); ?>

<?= $this->section('title'); ?>
<?= $page_title; ?>
<?= $this->endSection(); ?>
<?= $this->section('admin_dashboard_title'); ?>
<?= $page_title; ?>
<?= $this->endSection(); ?>

<?= $this->section('body'); ?>

<div class="container mt-5">
    <h1 style="text-align: center;">Under Construction</h1>
    <h1>Online Customers</h1>


</div>

<?= $this->endSection(); ?>