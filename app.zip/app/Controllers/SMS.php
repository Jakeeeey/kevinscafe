<?php

namespace App\Controllers;

use CodeIgniter\Controller;
//use Twilio\Rest\Client;

class SMS extends Controller
{

	public function __construct()
	{
		helper('form');
	}

	public function index()
	{
		$data['page_title'] = 'SMS';

		require_once 'vendor/autoload.php';
    //use Twilio\Rest\Client;

    $sid    = "ACd5dfeb75d394fa077ee7c4dab51eb0a4";
    $token  = "b0a101049e646c333a5951b4e56f6423";
    $twilio = new \Twilio\Rest\Client($sid, $token);

    $message = $twilio->messages
      ->create("+639510505308", // to
        array(
          "from" => "+15074739573",
          "body" => "Your order from Kevin's Cafe is now preparing"
        )
      );

print($message->sid);

		// require 'vendor/autoload.php';

		// $sid = "AC5447816e0478da3e75b62934b8c58f36"; // Your Account SID from https://console.twilio.com
		// $token = "2f075807f69814f75fd39b75ddf03224"; // Your Auth Token from https://console.twilio.com
		// $client = new \Twilio\Rest\Client($sid, $token);

		// // Use the Client to make requests to the Twilio REST API
		// $client->messages->create(
		// 	// The number you'd like to send the message to
		// 	'+639510505308',
		// 	[
		// 		// A Twilio phone number you purchased at https://console.twilio.com
		// 		'from' => '+15074739573',
		// 		// The body of the text message you'd like to send
		// 		'body' => "Hey Jenny! Good luck on the bar exam!"
		// 	]
		// );
	}
}
