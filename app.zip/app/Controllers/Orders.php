<?php 
    namespace App\Controllers;
    use CodeIgniter\Controller;
    use App\Models\OrdersModel;

    class Orders extends Controller{
    
        public $ordersModel;
        public function __construct(){
            helper('form');
            helper('date');
            //helper('date');
            $this->ordersModel = new OrdersModel();
        }


        public function index(){           
            $data['page_title'] = 'Orders';

            if(!session()->has('logged_admin')){
                return redirect()->to(base_url().'/login');
            }

            $data['orders'] = $this->ordersModel->getAllPlacedOrders();

            return view('pages/orders/orders_view', $data);
        }

        public function preparing(){
            $data['page_title'] = 'Preparing';
            
            $data['orders'] = $this->ordersModel->getAllPreparingOrders();

            return view('pages/orders/preparing_view', $data);
        }

        public function to_pickup(){
            $data['page_title'] = 'To Deliver';

            $data['orders'] = $this->ordersModel->getAllToPickupOrders();

            return view('pages/orders/to_pickup_view', $data);
        }

        public function to_deliver(){
            $data['page_title'] = 'To Deliver';

            $data['orders'] = $this->ordersModel->getAllToDeliverOrders();

            return view('pages/orders/to_deliver_view', $data);
        }

        public function get_order_details(){
            $placed_order_id = $_POST['placed_order_id'];
            $order_details = $this->ordersModel->getOrderDetails($placed_order_id);
            echo    '<table class="table table-hover">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Category</th>
                                <th>Menu Name</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody id="order-table">';
                        foreach($order_details as $order_detail){
            echo            '<tr>
                                <td><img src="'.base_url().'/public/uploads/'.$order_detail['menu_image'].'" alt="Menu Image" width="70"></td>
                                <td>'.$order_detail['category'].'</td>
                                <td>'.$order_detail['menu_name'].'</td>
                                <td>'.$order_detail['quantity'].'</td>
                            </tr>';
                        }
            echo        '</tbody>
                    </table>';

        }

        public function update_order_status(){
            $order_id = $_GET['order_id'];
            $order_status = $_GET['order_status'];
            $order_details = [
                'order_status' => $order_status,
                'updated_at' => date('Y-m-d h:i:s', now()),
            ];
            $status = $this->ordersModel->updateOrderStatus($order_id, $order_details);
            if($status){
                if($order_status == "preparing"){
                    return redirect()->to(base_url().'/orders/preparing');
                }elseif($order_status == "to_pickup"){
                    return redirect()->to(base_url().'/orders/to_pickup');
                }elseif($order_status == "to_deliver"){
                    return redirect()->to(base_url().'/orders/to_deliver');
                }elseif($order_status == "completed"){
                    return redirect()->to(base_url().'/sales1');
                }
            }
        }

    }
?>